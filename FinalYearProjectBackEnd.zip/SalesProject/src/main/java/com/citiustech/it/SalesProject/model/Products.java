package com.citiustech.it.SalesProject.model;

import java.util.Arrays;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.springframework.data.relational.core.sql.FalseCondition;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="products")
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Data
public class Products {

	@Id
	private int pno;
	private String productName;
	private double price;
	private int stock;
	
	@Lob
	@Column(length=1000, nullable=false)
	private byte[] image;
	
}
