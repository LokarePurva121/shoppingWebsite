package com.citiustech.it.SalesProject.service;

import java.util.Collection;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.citiustech.it.SalesProject.model.Invoice;
import com.citiustech.it.SalesProject.repository.InvoiceRepository;

@Service
public class InvoiceService {

	 	@Autowired
	    private InvoiceRepository invoiceRepository;
	    
	 	@Transactional
	    public List<Invoice> getAllInvoices(String custId){
	    	return invoiceRepository.findByCustId(custId);
	    }
	
	 	

}
