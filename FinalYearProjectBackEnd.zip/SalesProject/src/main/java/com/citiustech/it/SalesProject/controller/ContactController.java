package com.citiustech.it.SalesProject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.citiustech.it.SalesProject.model.Contact;
import com.citiustech.it.SalesProject.model.Orders;
import com.citiustech.it.SalesProject.service.ContactService;

@RestController
@EnableWebMvc
@RequestMapping("contact")
@CrossOrigin(origins="http://127.0.0.1:5501/")
public class ContactController {
	
	@Autowired
	private ContactService contactService;
	
//	 @PostMapping(value="place", consumes="application/json")
//	    public Orders saveOrder(@RequestBody Orders orders){
//	    	System.out.println(orders);
////	    	System.out.println(invoice);
//	        return orderService.saveorders(orders);
//	    }
	
	
	@PostMapping(value="save", consumes="application/json")
	public Contact saveContact(@RequestBody Contact contact){
		System.out.println(contact);
		return contactService.SaveContact(contact);
	}
	
}
