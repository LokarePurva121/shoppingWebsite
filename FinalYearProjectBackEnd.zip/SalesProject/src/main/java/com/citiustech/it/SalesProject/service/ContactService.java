package com.citiustech.it.SalesProject.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citiustech.it.SalesProject.model.Contact;
import com.citiustech.it.SalesProject.model.Customers;
import com.citiustech.it.SalesProject.repository.ContactRepository;
import com.citiustech.it.SalesProject.repository.CustomerRepository;

@Service
public class ContactService {
	
	 @Autowired
	 private CustomerRepository customerRepository;
	 
	 @Autowired
	 private ContactRepository contactRepository;
	 
	 
	 @Transactional
	 public Contact SaveContact(Contact contact) {
		 
		 Customers ctr = customerRepository.findByCustId(contact.getCustId());
		 
		 contact.setCustId(ctr.getCustId());
		 contact.setEmail(contact.getEmail());
		 contact.setMsg(contact.getMsg());
		 
		 return contactRepository.save(contact);
		 
		 
		
	}

}
