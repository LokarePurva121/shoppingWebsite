package com.citiustech.it.SalesProject.controller;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

import javax.servlet.annotation.MultipartConfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.citiustech.it.SalesProject.model.Products;
import com.citiustech.it.SalesProject.service.ProductService;

//@CrossOrigin
@EnableWebMvc
@RestController
@RequestMapping("products")
@CrossOrigin(origins="http://127.0.0.1:5501")
public class ProductController {

	@Autowired
	private ProductService productService;

	
	@PostMapping(value="save")
	public String saveProduct(@RequestParam("image") MultipartFile file,
			@RequestParam("pno") int pno,
			@RequestParam("productName") String productName,
			@RequestParam("price") double price,
			@RequestParam("stock") int stock) throws IOException {
		productService.saveProduct(file, pno,productName, price, stock);
		
		return "success";

	}

	
	@GetMapping(value="all")
	public List<Products> getAllProducts(){
		return productService.getAllProducts();
	}
	
	@GetMapping(value="/{id}")
	public Products getProductById(@PathVariable int id){
		return productService.getProductById(id);
	}
	
	@GetMapping(value="image/{id}")
	public ResponseEntity<?> getimage(@PathVariable int id){
		byte[] imageData=productService.getimage(id);
		return ResponseEntity.status(HttpStatus.OK)
				.contentType(MediaType.valueOf("image/png"))
				.body(imageData);
	}
	
	
	
	
	@PutMapping(value="update/{id}")
	public void updateProduct(@PathVariable int id,@RequestParam("image") MultipartFile file,
			@RequestParam("pno") int pno,
			@RequestParam("productName") String productName,
			@RequestParam("price") double price,
			@RequestParam("stock") int stock) throws IOException{
		productService.updateProduct(id,file, pno,productName, price, stock);
	}
	
	@DeleteMapping(value="delete/{id}", consumes="application/json")
	public void deleteProduct(@PathVariable int id) {
		productService.deleteProduct(id);
	}
	
}
