package com.citiustech.it.SalesProject.service;

import java.awt.Image;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import javax.imageio.stream.ImageOutputStream;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.citiustech.it.SalesProject.model.Products;
import com.citiustech.it.SalesProject.repository.ProductRepository;
import com.citiustech.it.SalesProject.util.*;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepository;

	@Transactional
	public void saveProduct(MultipartFile file, int pno,String productName, double price, int stock) throws IOException {

		Products p = new Products();
		p.setPno(pno);
		p.setProductName(productName);
		p.setPrice(price);
		p.setStock(stock);
		p.setImage(ImageUtils.compressImage(file.getBytes()));
		
		
		productRepository.save(p);
	}


	@Transactional
	public List<Products> getAllProducts() {
		
		return productRepository.findAll();

	}
	
	@Transactional
	public Products getProductById(int id) {
		return productRepository.findByPno(id);
	
	}
	

	@Transactional
	public byte[] getimage(int id) {

		Optional<Products> dbImageData = productRepository.findById(id);
		byte[] images = ImageUtils.decompressImage(dbImageData.get().getImage());
		return images;

	}

	@Transactional
	public void deleteProduct(int id) {
		productRepository.deleteById(id);
	}

	@Transactional
	public void updateProduct(int id, MultipartFile file, int pno,String productName, double price, int stock) throws IOException {
		Products p = new Products();
		p.setPno(pno);
		p.setProductName(productName);
		p.setPrice(price);
		p.setStock(stock);
		p.setImage(ImageUtils.compressImage(file.getBytes()));

		productRepository.save(p);
	}

}