package com.citiustech.it.SalesProject.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.citiustech.it.SalesProject.model.Customers;
import com.citiustech.it.SalesProject.model.Products;

@Repository
public interface ProductRepository extends JpaRepository<Products, Integer>{
	
	Products findByPno(int id);

//	Products save(Products products, Products build);

//		Customers findByCustId(String id);
//	Optional<Products> findById(int id);

	
	
}
