package com.citiustech.it.SalesProject.exceptions;

public class CutomerNotFound extends RuntimeException{

	public CutomerNotFound(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
