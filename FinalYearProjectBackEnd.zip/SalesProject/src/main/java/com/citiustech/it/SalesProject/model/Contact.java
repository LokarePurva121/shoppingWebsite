package com.citiustech.it.SalesProject.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Contact")
public class Contact {
	@Id
	private String email;
	private String custId;
	private String msg;
	
	public Contact() {
		
	}
	
	public Contact(String email, String msg) {
		this.email = email;
		this.msg = msg;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	


	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	@Override
	public String toString() {
		return "Contact [email=" + email + ", custId=" + custId + ", msg=" + msg + "]";
	}

	

	   
	   
}
