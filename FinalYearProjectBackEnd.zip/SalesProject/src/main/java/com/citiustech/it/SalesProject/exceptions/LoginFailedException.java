package com.citiustech.it.SalesProject.exceptions;

public class LoginFailedException extends RuntimeException {

	public LoginFailedException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
