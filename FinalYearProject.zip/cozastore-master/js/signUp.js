$(document).ready(() => {
    $('#submit').click(() => {
        var username = $('#username').val();
        var email = $('#email').val();
        var password = $('#password').val();
        var credit = $('#credit').val();

        if (username === '' || password === '' || email === '' || credit === '') {
            alert("Please enter proper details!");
        } else {
            var data = {
                custId: username,
                email: email,
                pwd: password,
                credit: credit
            }

            console.log(data);
            var dataObject = JSON.stringify(data);
            console.log(dataObject);
            $.post({
                url: 'http://localhost:8083/customers/save',
                data: dataObject,
                contentType: 'application/json'

            }).done(data => {

                // window.localStorage.setItem("CustomerID", data.CustomerId);
                window.location.href = "login.html";

            }).fail(data => {
                console.log(data);
                alert(data.responseJSON.errorMessage);
            })
        }
    })
})