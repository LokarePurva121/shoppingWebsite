$(document).ready(() => {

    $('#placeorder').click(()=>{
        var url = window.location.href;

        var file = url.substring(url.lastIndexOf('?')+5);
        console.log(file);

        var quantity = $('#quantity').val();
        console.log(quantity);

        if(quantity === ''){
            alert("Enter Quantity");
        }else{
            let new_req = {    
                    customers: {
                      custId: window.localStorage.getItem('CustomerID'),
                    },
                    products: {
                      pno: file,
                    },
                    qty: quantity
                
            }

            $.ajax({
                type: "POST",
                url: 'http://localhost:8083/orders/place',
                data: JSON.stringify(new_req),
                dataType: 'application/json',
                contentType:'application/json',
                success : function(data) {
                    console.log(data);

                } 
            }); 
        } 
    }); 
    $('#logout').click(()=>{
        window.localStorage.clear();
        window.location.href="http://127.0.0.1:5501/index.html";
      });
})
