$(document).ready(() => {

    console.log("hello");
    var url = window.location.href;

        var file = url.substring(url.lastIndexOf('?')+1);
        console.log(file);

    $('#ww').click(()=>{
        var email = $('#email').val();
        console.log(email);
       
        var msg = $('#msg').val();
        console.log(msg);

        
     
        if(email === '' && msg === ''){
            alert("Please fill details");
        }else{
            let new_req = {    
                    // customers: {
                    //   custId: window.localStorage.getItem('CustomerID'),
                    // },
                    // products: {
                    //   pno: file,
                    // },
                    // qty: quantity
                
                    custId: file,
                    email : email,
                    msg : msg
                
            }
            alert("Thank you for reaching us!")
            // console.log(custId);
            $.ajax({
                type: "POST",
                mode: 'no-cors',
                url: 'http://localhost:8083/contact/save',
                data: JSON.stringify(new_req),
                dataType: 'application/json',
                contentType:'application/json',
                success : function(data) {
                    
                    console.log(data);

                } 
            }); 
        } 
    }); 
    $('#logout').click(()=>{
        window.localStorage.clear();
        window.location.href="http://127.0.0.1:5501/index.html";
      });
})
